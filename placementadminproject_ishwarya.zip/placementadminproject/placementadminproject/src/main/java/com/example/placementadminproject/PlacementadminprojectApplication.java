package com.example.placementadminproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementadminprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementadminprojectApplication.class, args);
	}

}
