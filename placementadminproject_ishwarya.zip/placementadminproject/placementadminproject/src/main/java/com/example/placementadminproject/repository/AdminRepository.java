package com.example.placementadminproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.placementadminproject.entities.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long> {
}
