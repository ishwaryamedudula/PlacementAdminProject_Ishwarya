package com.example.placementadminproject.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.placementadminproject.entities.Admin;
import com.example.placementadminproject.repository.AdminRepository;

@Service
public class AdminService {
    
    @Autowired
    private AdminRepository adminRepository;

    //Create Admin
    public Admin addAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    //Get All Admins
    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    //Update Admin
    public Admin updateAdmin(Admin admin) {
        Admin existingAdmin = adminRepository.findById(admin.getId()).orElse(null);
        if (existingAdmin != null) {
            existingAdmin.setName(admin.getName());
            existingAdmin.setPassword(admin.getPassword()); 
            return adminRepository.save(existingAdmin);
        }
        return null; 
    }

    //Delete Admin
    public void deleteAdmin(Long id) {
        adminRepository.deleteById(id);
    }
}
